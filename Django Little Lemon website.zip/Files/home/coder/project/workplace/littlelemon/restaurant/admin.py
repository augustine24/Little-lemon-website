from django.contrib import admin
from .models import Menu

# Register your models here. <-- AUGU WAS HERE
admin.site.register(Menu)
